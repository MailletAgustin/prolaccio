const express = require('express');
const app = express();
const path = require('path');

app.set('port', process.env.port || 80) 

app.post('/notificacion/pago', (req, res, next) =>{
    console.log(req);
    console.log(res);
    res.send(200);
})

app.listen(app.get('port'), server =>{
    console.info(`Server listen on port ${app.get('port')}`);
})